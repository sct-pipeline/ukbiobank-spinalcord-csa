# Projet3
Mesure de l’aire de section médullaire sur la base de données UK Biobank
